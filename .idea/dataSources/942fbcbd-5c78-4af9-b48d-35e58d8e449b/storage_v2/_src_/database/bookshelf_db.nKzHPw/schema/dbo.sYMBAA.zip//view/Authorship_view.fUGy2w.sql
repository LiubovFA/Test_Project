CREATE VIEW Authorship_view AS
SELECT Book.Name AS Book_Name, 
        Author.Full_name AS Author_Name 
FROM Book INNER JOIN Authorship ON Authorship.Id_book = Book.Id_book
INNER JOIN Author ON Author.Id_author = Authorship.Id_author
go

